
def area_quad(lado):
    return lado * lado

def area_retang(base, altura):
    return base * altura

