import my_math


print('*** Iremos calcular a area de um quadrado e a area de um retangulo ***')
quadrado = int(input('Digite o Lado do quadrado ex.: 5 >>>  '))
calc = my_math.area_quad(quadrado)
print('Seu quadrado possui a medida de {}'.format(calc))

base = int(input('OTIMO, Agora digite a base do retangulo: '))
altura = int(input('agora digite a altura do retangulo: '))
calc = my_math.area_retang(base, altura)
print('Seu retangulo possuia a medida de {}'.format(calc))
